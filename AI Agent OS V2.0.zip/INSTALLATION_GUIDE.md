# AI Project OS v2.0 - Installation & Usage Guide

## What You're Getting

A production-ready AI project orchestration system that fixes ALL issues from the original version.

### Package Contents

```
ai-project-os-v2.0.zip
└── ai-project-os-v2/
    ├── generate_ai_project.sh    # Main generator script
    ├── README.md                  # Complete documentation
    ├── QUICKSTART.md             # 3-minute setup guide
    ├── CHANGELOG.md              # Version history
    └── LICENSE                    # MIT License
```

## Installation

### Step 1: Extract Package

```bash
unzip ai-project-os-v2.0.zip
cd ai-project-os-v2
```

### Step 2: Generate Your Project

```bash
# Make generator executable
chmod +x generate_ai_project.sh

# Generate new project
./generate_ai_project.sh my-ai-project

# Or with GitHub repo
./generate_ai_project.sh my-ai-project your-username/repo-name
```

This creates complete project structure with all files.

### Step 3: Setup Generated Project

```bash
cd my-ai-project

# Install Python 3.11+ (if needed)
# macOS: brew install python@3.11
# Ubuntu: sudo apt install python3.11

# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate  # Linux/Mac
# OR
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Install pre-commit hooks
pre-commit install
```

### Step 4: Configure Environment

```bash
# Copy template
cp .env.template .env

# Edit with your API keys
nano .env
```

Add your keys:
```
OPENAI_API_KEY=sk-your-openai-key-here
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key
GITHUB_TOKEN=ghp_your-github-token
AI_PROJECT_ENV=dev
```

## Usage

### CLI Commands

```bash
# Get help
python -m cli.main --help

# Create a task
python -m cli.main create task_001 "Add user authentication" \
  --description "Implement JWT-based authentication" \
  --files "src/auth/**/*.py" "tests/auth/**/*.py"

# View all tasks
python -m cli.main status

# Run pending tasks
python -m cli.main run

# Approve a waiting task
python -m cli.main approve task_001
```

### Task Structure

Tasks are JSON files in `tasks/pending/`:

```json
{
  "task_id": "auth_feature_001",
  "title": "Add OAuth2 support",
  "description": "Implement OAuth2 authentication flow",
  "allowed_files": [
    "src/auth/**/*.py",
    "tests/auth/**/*.py"
  ],
  "tests": [
    "pytest tests/auth/test_oauth.py"
  ],
  "created_at": "2024-03-16T10:00:00Z"
}
```

### Docker Usage

```bash
# Set environment variables
export OPENAI_API_KEY=sk-...
export GITHUB_TOKEN=ghp_...

# Start container
docker-compose up -d

# View logs
docker-compose logs -f ai-agent

# Stop container
docker-compose down
```

## Integration with Existing Git Repo

### Option 1: New Repo
Generator creates new repo automatically.

### Option 2: Add to Existing Repo

```bash
# Generate in new location
./generate_ai_project.sh my-project

# Copy to existing repo
cd my-project
cp -r * /path/to/existing/repo/
cd /path/to/existing/repo

# Merge .gitignore carefully
cat .gitignore >> ../.gitignore.backup
# Edit .gitignore to avoid duplicates

# Commit
git add .
git commit -m "Add AI Project OS v2.0"
```

### Option 3: Separate Branch

```bash
cd your-existing-repo

# Create new branch
git checkout -b ai-agent-system

# Generate project in temp location
cd /tmp
/path/to/generate_ai_project.sh ai-temp

# Copy files
cp -r ai-temp/* /path/to/your-existing-repo/

# Commit on branch
cd /path/to/your-existing-repo
git add .
git commit -m "Add AI agent system"
git push origin ai-agent-system
```

## What's Different from v1.0

### Fixed Issues
✅ Race conditions in memory (file locking added)
✅ No error handling (comprehensive try-catch)
✅ Hardcoded paths (Path objects)
✅ No input validation (argparse)
✅ No dependencies file (requirements.txt)
✅ No logging (structured logging)
✅ No tests (complete pytest suite)
✅ No CLI (Rich terminal UI)
✅ No Docker (full containerization)

### New Features
✅ State management with persistence
✅ Task status tracking
✅ Memory system for agents
✅ Semantic code indexing
✅ Configuration management
✅ CI/CD pipelines
✅ Documentation (ADRs, guides)
✅ Examples and workflows
✅ Setup automation

## Customization

### Change LLM Provider

Edit `config/agents.yml`:

```yaml
agents:
  planner:
    model: "claude-3-opus-20240229"  # Use Claude instead
    max_tokens: 4000
    temperature: 0.7
```

### Add Custom Skills

Create in `agents/skills/`:

```python
# agents/skills/security_review.py
class SecurityReviewSkill:
    def analyze(self, code):
        # Your security analysis logic
        return findings
```

### Modify Task Workflow

Edit `agents/planner/task_planner.py`:

```python
def plan_task(self, task):
    plan["steps"].append({
        "id": "security_scan",
        "action": "run_security_scan",
        "duration": 60
    })
    return plan
```

## Testing

```bash
# Run all tests
pytest

# With coverage report
pytest --cov=. --cov-report=html

# Open coverage report
open htmlcov/index.html

# Run specific test
pytest tests/unit/test_state_manager.py -v

# Type checking
mypy .

# Code formatting
black .

# Linting
flake8 .
```

## Production Deployment

### Using Docker

```bash
# Build production image
docker build -t ai-project-os:prod .

# Run with production config
docker run -d \
  --name ai-agent-prod \
  -v $(pwd)/tasks:/app/tasks \
  -v $(pwd)/runs:/app/runs \
  -e OPENAI_API_KEY=$OPENAI_API_KEY \
  -e AI_PROJECT_ENV=prod \
  ai-project-os:prod
```

### Using systemd (Linux)

```bash
# Create service file
sudo nano /etc/systemd/system/ai-agent.service
```

```ini
[Unit]
Description=AI Project OS Agent
After=network.target

[Service]
Type=simple
User=your-user
WorkingDirectory=/path/to/project
Environment="OPENAI_API_KEY=sk-..."
ExecStart=/path/to/project/venv/bin/python -m cli.main run
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start
sudo systemctl enable ai-agent
sudo systemctl start ai-agent

# Check status
sudo systemctl status ai-agent

# View logs
sudo journalctl -u ai-agent -f
```

## Monitoring

### View Logs

```bash
# Orchestrator logs
tail -f runs/logs/orchestrator.log

# All logs
tail -f runs/logs/*.log
```

### Check Task States

```bash
# CLI status
python -m cli.main status

# Raw state file
cat runs/task_states.json | jq '.'

# Specific task
cat runs/task_states.json | jq '.task_001'
```

### Memory Inspection

```bash
# All memories
cat core/memory/store.json | jq '.'

# Task-specific memories
cat core/memory/store.json | jq '.[] | select(.task_id=="task_001")'

# Recent memories
cat core/memory/store.json | jq '.[-10:]'
```

## Troubleshooting

### Import Errors

```bash
# Ensure virtual environment is active
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### Permission Denied

```bash
# Fix script permissions
chmod +x scripts/**/*.sh
chmod +x generate_ai_project.sh
```

### Docker Issues

```bash
# Rebuild without cache
docker-compose build --no-cache

# Remove old containers
docker-compose down -v

# Start fresh
docker-compose up -d
```

### Pre-commit Hooks Failing

```bash
# Update hooks
pre-commit autoupdate

# Run manually
pre-commit run --all-files

# Skip hooks temporarily (not recommended)
git commit --no-verify
```

## Documentation

Complete docs in generated project:

- `README.md` - Project overview
- `docs/guides/` - User guides
- `docs/api/` - API documentation
- `docs/architecture/` - Architecture Decision Records
- `examples/` - Example tasks and workflows

## Support & Resources

### Generated Project Files
- Configuration: `config/agents.yml`
- Environment: `.env`
- Tasks: `tasks/pending/*.json`
- Logs: `runs/logs/`
- State: `runs/task_states.json`
- Memory: `core/memory/store.json`

### Key Modules
- Orchestrator: `core/orchestrator/runner.py`
- State Manager: `core/state/task_state.py`
- Memory: `core/memory/memory.py`
- Planner: `agents/planner/task_planner.py`
- CLI: `cli/main.py`

### Useful Commands

```bash
# Full system status
python -m cli.main status

# Create test task
python -m cli.main create test "Test task" --files "**/*.py"

# Watch logs
tail -f runs/logs/orchestrator.log

# Check recent memory
cat core/memory/store.json | jq '.[-5:]'

# View repository index
cat core/repo_index/repo_graph.json | jq '.metadata'
```

## Next Steps

1. ✅ Install and generate project
2. ✅ Configure environment variables
3. ✅ Create first task
4. ✅ Run orchestrator
5. ✅ Customize agents
6. ✅ Add LLM integration
7. ✅ Deploy to production

Your AI project is production-ready!
